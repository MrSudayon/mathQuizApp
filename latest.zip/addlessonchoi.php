<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Lesson Unit</title>
</head>
<body>
<center>
<form method="get" action="dash.php?q=5">
    <button type="submit" class="button" 
                style="
               background: #148110;
                width: 80%;
                height: 50px;
                border-bottom-left-radius: 10px;
                border-bottom-right-radius: 10px;
                border-top-left-radius: 10px;
                border-top-right-radius: 10px;
                color: white;border: 0;
                -webkit-appearance: none">Back</button>
</form>
<main><center><br>
<form method="get" action="lessons.php">
    <button type="submit" class="button" 
                style="
                background: #148110;
                width: 80%;
                height: 50px;
                border-bottom-left-radius: 10px;
                border-bottom-right-radius: 10px;
                border-top-left-radius: 10px;
                border-top-right-radius: 10px;
                color: white;border: 0;
                -webkit-appearance: none">Add Lesson for Unit 1</button>
</form><br>
<form method="get" action="lessons2.php">
    <button type="submit" class="button" 
                style="
                background: #148110;
                width: 80%;
                height: 50px;
                border-bottom-left-radius: 10px;
                border-bottom-right-radius: 10px;
                border-top-left-radius: 10px;
                border-top-right-radius: 10px;
                color: white;border: 0;
                -webkit-appearance: none">Add Lesson for Unit 2</button>
</form><br>
<form method="get" action="lessons3.php">
    <button type="submit" class="button" 
                style="
                background: #148110;
                width: 80%;
                height: 50px;
                border-bottom-left-radius: 10px;
                border-bottom-right-radius: 10px;
                border-top-left-radius: 10px;
                border-top-right-radius: 10px;
                color: white;border: 0;
                -webkit-appearance: none">Add Lesson for Unit 3</button>
</form><br>
<form method="get"action="lessons4.php">
    <button type="submit" class="button" 
                style="
                background: #148110;
                width: 80%;
                height: 50px;
                border-bottom-left-radius: 10px;
                border-bottom-right-radius: 10px;
                border-top-left-radius: 10px;
                border-top-right-radius: 10px;
                color: white;border: 0;
                -webkit-appearance: none">Add Lesson for Unit 4</button>
</form>

</center>
</body>
</html>