localhost/math/adlogin.php // Teacher mode login session
localhost/math/adminlogin.php // Admin mode
localhost/math/Login Student

Bago kayo magstart iopen niyo muna yung adlogin.php ayun yung teachermode. then mag addmuna kayo ng lesson each units 
para ma okay tas sabay kayo mag ng mga quiz then users para maayos yung database niyo. 

Tol lahat ng mali pati mga text pati icons inayos ko na pati colors nasa note yung mga need niyo. okay na to. 4 set of units list lessons. 
then yun nga nasunod lahat ng nakalagay dunnsa word pati yung mga pinapabagong text may mga dinagdag din ako kayo na bahala mag explore pero 
wala na kayo gagawin dito kung di paganhin nalang basahin niyo nalng yung readme.txt. yung quiz.sql wla yun laman admin lang ititra ko dun na
laman para maaccess niyo padin lahat kayo na bahala maglagay ng quiz lesson don. 2 araw kong pinag aayos finix lahat. tyty

